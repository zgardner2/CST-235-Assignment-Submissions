package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;

@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface {

	List<Order> orders = new ArrayList<Order>();

	@Override
	public void test() {
		System.out.println("Look it's the OrdersBusinessService");

	}

	public OrdersBusinessService() {

		orders.add(new Order("00001", "Wifi PCIe card", (float) 29.99, 3));
		orders.add(new Order("00002", "DDR4 Ram 4Gig", (float) 49.99, 4));
		orders.add(new Order("00003", "Micro atx Motherboard", (float) 69.99, 1));
		orders.add(new Order("00004", "GTX 1050ti Graphics card", (float) 159.99, 1));
		orders.add(new Order("00005", "Intel Core i7 7700k Processor", (float) 329.99, 1));
	}

	@Override
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders) {
		// TODO Auto-generated method stub
		this.orders = orders;
	}

}
