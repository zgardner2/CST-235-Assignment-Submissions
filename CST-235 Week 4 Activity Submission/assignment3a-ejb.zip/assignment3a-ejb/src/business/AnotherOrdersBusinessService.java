package business;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Local;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import beans.Order;

@Stateless
@Local(OrdersBusinessInterface.class)
@Alternative
public class AnotherOrdersBusinessService implements OrdersBusinessInterface{
	
	List<Order> orders = new ArrayList<Order>();
	
	 public AnotherOrdersBusinessService() {
	    	
			
			orders.add(new Order("0000a", "Dual Socket server Motherboard", (float)209.99, 1));
			orders.add(new Order("0000b", "64gig DDR4 Ram set 8Gig X 8", (float)249.99, 1));
			orders.add(new Order("0000c", "Dual Powersupply", (float)169.99, 1));
			orders.add(new Order("0000d", "GTX 2080 ti Graphics card", (float)1059.99, 4));
			orders.add(new Order("0000e", "Intel Xeon 16 Core Processor", (float)529.99, 2));
	    }

	@Override
	public void test() {
		System.out.println("Look it's AnotherOrdersBusinessService");
		
	}

	@Override
	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return orders;
	}

	@Override
	public void setOrders(List<Order> orders) {
		this.orders = orders;
		
	}

}
