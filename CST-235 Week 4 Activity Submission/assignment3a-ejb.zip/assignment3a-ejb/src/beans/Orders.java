package beans;

import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

@ManagedBean
@ViewScoped
public class Orders {
	List<Order> orders = new ArrayList<Order>();
		
	
	public Orders() {
		orders.add(new Order("00001", "Wifi PCIe card", (float)29.99, 3));
		orders.add(new Order("00002", "DDR4 Ram 4Gig", (float)49.99, 4));
		orders.add(new Order("00003", "Micro atx Motherboard", (float)69.99, 1));
		orders.add(new Order("00004", "GTX 1050ti Graphics card", (float)159.99, 1));
		orders.add(new Order("00005", "Intel Core i7 7700k Processor", (float)329.99, 1));
	}
	
	
	
	
	public List<Order> getOrders() {
		return orders;
	}

	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}
	
}
